gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects1= [];
gdjs.Untitled_32sceneCode.GDTransitionObjects2= [];
gdjs.Untitled_32sceneCode.GDColored_9595ConfettiObjects1= [];
gdjs.Untitled_32sceneCode.GDColored_9595ConfettiObjects2= [];
gdjs.Untitled_32sceneCode.GDShadowObjects1= [];
gdjs.Untitled_32sceneCode.GDShadowObjects2= [];
gdjs.Untitled_32sceneCode.GDLeaves_95959PatchObjects1= [];
gdjs.Untitled_32sceneCode.GDLeaves_95959PatchObjects2= [];
gdjs.Untitled_32sceneCode.GDDust_9595ParticleObjects1= [];
gdjs.Untitled_32sceneCode.GDDust_9595ParticleObjects2= [];
gdjs.Untitled_32sceneCode.GDGreen_9595Grass_95959PatchObjects1= [];
gdjs.Untitled_32sceneCode.GDGreen_9595Grass_95959PatchObjects2= [];
gdjs.Untitled_32sceneCode.GDOrange_9595Grass_95959PatchObjects1= [];
gdjs.Untitled_32sceneCode.GDOrange_9595Grass_95959PatchObjects2= [];
gdjs.Untitled_32sceneCode.GDPink_9595Grass_95959PatchObjects1= [];
gdjs.Untitled_32sceneCode.GDPink_9595Grass_95959PatchObjects2= [];
gdjs.Untitled_32sceneCode.GDWood_95959PatchObjects1= [];
gdjs.Untitled_32sceneCode.GDWood_95959PatchObjects2= [];
gdjs.Untitled_32sceneCode.GDStone_95959PatchObjects1= [];
gdjs.Untitled_32sceneCode.GDStone_95959PatchObjects2= [];
gdjs.Untitled_32sceneCode.GDGold_9595PlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDGold_9595PlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDStone_9595PlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDStone_9595PlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDBullet_9595PiecesObjects1= [];
gdjs.Untitled_32sceneCode.GDBullet_9595PiecesObjects2= [];
gdjs.Untitled_32sceneCode.GDWood_9595PlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDWood_9595PlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces2Objects1= [];
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces2Objects2= [];
gdjs.Untitled_32sceneCode.GDBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDBullet2Objects1= [];
gdjs.Untitled_32sceneCode.GDBullet2Objects2= [];
gdjs.Untitled_32sceneCode.GDLeafsObjects1= [];
gdjs.Untitled_32sceneCode.GDLeafsObjects2= [];
gdjs.Untitled_32sceneCode.GDOrange_9595ParticleObjects1= [];
gdjs.Untitled_32sceneCode.GDOrange_9595ParticleObjects2= [];
gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects1= [];
gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects2= [];
gdjs.Untitled_32sceneCode.GDAppearingObjects1= [];
gdjs.Untitled_32sceneCode.GDAppearingObjects2= [];
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces3Objects1= [];
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces3Objects2= [];
gdjs.Untitled_32sceneCode.GDBullet3Objects1= [];
gdjs.Untitled_32sceneCode.GDBullet3Objects2= [];
gdjs.Untitled_32sceneCode.GDGost_9595ParticlesObjects1= [];
gdjs.Untitled_32sceneCode.GDGost_9595ParticlesObjects2= [];
gdjs.Untitled_32sceneCode.GDSlime_9595ParticlesObjects1= [];
gdjs.Untitled_32sceneCode.GDSlime_9595ParticlesObjects2= [];
gdjs.Untitled_32sceneCode.GDChainObjects1= [];
gdjs.Untitled_32sceneCode.GDChainObjects2= [];
gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1= [];
gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects2= [];
gdjs.Untitled_32sceneCode.GDSpikesObjects1= [];
gdjs.Untitled_32sceneCode.GDSpikesObjects2= [];
gdjs.Untitled_32sceneCode.GDDesappearingObjects1= [];
gdjs.Untitled_32sceneCode.GDDesappearingObjects2= [];
gdjs.Untitled_32sceneCode.GDArrowObjects1= [];
gdjs.Untitled_32sceneCode.GDArrowObjects2= [];
gdjs.Untitled_32sceneCode.GDBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDFalling_9595PlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDFalling_9595PlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDFanObjects1= [];
gdjs.Untitled_32sceneCode.GDFanObjects2= [];
gdjs.Untitled_32sceneCode.GDChain2Objects1= [];
gdjs.Untitled_32sceneCode.GDChain2Objects2= [];
gdjs.Untitled_32sceneCode.GDFireObjects1= [];
gdjs.Untitled_32sceneCode.GDFireObjects2= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects1= [];
gdjs.Untitled_32sceneCode.GDPlatformObjects2= [];
gdjs.Untitled_32sceneCode.GDRock_9595HeadObjects1= [];
gdjs.Untitled_32sceneCode.GDRock_9595HeadObjects2= [];
gdjs.Untitled_32sceneCode.GDSawObjects1= [];
gdjs.Untitled_32sceneCode.GDSawObjects2= [];
gdjs.Untitled_32sceneCode.GDTrampolineObjects1= [];
gdjs.Untitled_32sceneCode.GDTrampolineObjects2= [];
gdjs.Untitled_32sceneCode.GDSpike_9595HeadObjects1= [];
gdjs.Untitled_32sceneCode.GDSpike_9595HeadObjects2= [];
gdjs.Untitled_32sceneCode.GDChain3Objects1= [];
gdjs.Untitled_32sceneCode.GDChain3Objects2= [];
gdjs.Untitled_32sceneCode.GDCheckpoint_95952Objects1= [];
gdjs.Untitled_32sceneCode.GDCheckpoint_95952Objects2= [];
gdjs.Untitled_32sceneCode.GDCheckpointObjects1= [];
gdjs.Untitled_32sceneCode.GDCheckpointObjects2= [];
gdjs.Untitled_32sceneCode.GDTrophyObjects1= [];
gdjs.Untitled_32sceneCode.GDTrophyObjects2= [];
gdjs.Untitled_32sceneCode.GDBox1Objects1= [];
gdjs.Untitled_32sceneCode.GDBox1Objects2= [];
gdjs.Untitled_32sceneCode.GDBox3Objects1= [];
gdjs.Untitled_32sceneCode.GDBox3Objects2= [];
gdjs.Untitled_32sceneCode.GDBox2Objects1= [];
gdjs.Untitled_32sceneCode.GDBox2Objects2= [];
gdjs.Untitled_32sceneCode.GDAppleObjects1= [];
gdjs.Untitled_32sceneCode.GDAppleObjects2= [];
gdjs.Untitled_32sceneCode.GDBananasObjects1= [];
gdjs.Untitled_32sceneCode.GDBananasObjects2= [];
gdjs.Untitled_32sceneCode.GDKiwiObjects1= [];
gdjs.Untitled_32sceneCode.GDKiwiObjects2= [];
gdjs.Untitled_32sceneCode.GDMelonObjects1= [];
gdjs.Untitled_32sceneCode.GDMelonObjects2= [];
gdjs.Untitled_32sceneCode.GDCherriesObjects1= [];
gdjs.Untitled_32sceneCode.GDCherriesObjects2= [];
gdjs.Untitled_32sceneCode.GDCollectedObjects1= [];
gdjs.Untitled_32sceneCode.GDCollectedObjects2= [];
gdjs.Untitled_32sceneCode.GDOrangeObjects1= [];
gdjs.Untitled_32sceneCode.GDOrangeObjects2= [];
gdjs.Untitled_32sceneCode.GDBeeObjects1= [];
gdjs.Untitled_32sceneCode.GDBeeObjects2= [];
gdjs.Untitled_32sceneCode.GDPineappleObjects1= [];
gdjs.Untitled_32sceneCode.GDPineappleObjects2= [];
gdjs.Untitled_32sceneCode.GDStrawberryObjects1= [];
gdjs.Untitled_32sceneCode.GDStrawberryObjects2= [];
gdjs.Untitled_32sceneCode.GDAngryPigObjects1= [];
gdjs.Untitled_32sceneCode.GDAngryPigObjects2= [];
gdjs.Untitled_32sceneCode.GDBatObjects1= [];
gdjs.Untitled_32sceneCode.GDBatObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueBirdObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueBirdObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDAnswerEntryObjects1= [];
gdjs.Untitled_32sceneCode.GDAnswerEntryObjects2= [];
gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1= [];
gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects2= [];
gdjs.Untitled_32sceneCode.GDNewText2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDWATERObjects1= [];
gdjs.Untitled_32sceneCode.GDWATERObjects2= [];
gdjs.Untitled_32sceneCode.GD_95953Objects1= [];
gdjs.Untitled_32sceneCode.GD_95953Objects2= [];
gdjs.Untitled_32sceneCode.GD_95952Objects1= [];
gdjs.Untitled_32sceneCode.GD_95952Objects2= [];
gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1= [];
gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDsafeObjects1= [];
gdjs.Untitled_32sceneCode.GDsafeObjects2= [];
gdjs.Untitled_32sceneCode.GDsacrificeObjects1= [];
gdjs.Untitled_32sceneCode.GDsacrificeObjects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects2= [];
gdjs.Untitled_32sceneCode.GDfoodObjects1= [];
gdjs.Untitled_32sceneCode.GDfoodObjects2= [];
gdjs.Untitled_32sceneCode.GDgirlfriendObjects1= [];
gdjs.Untitled_32sceneCode.GDgirlfriendObjects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects2= [];
gdjs.Untitled_32sceneCode.GD_95954Objects1= [];
gdjs.Untitled_32sceneCode.GD_95954Objects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects2= [];
gdjs.Untitled_32sceneCode.GDch1Objects1= [];
gdjs.Untitled_32sceneCode.GDch1Objects2= [];
gdjs.Untitled_32sceneCode.GDch2Objects1= [];
gdjs.Untitled_32sceneCode.GDch2Objects2= [];
gdjs.Untitled_32sceneCode.GDch3Objects1= [];
gdjs.Untitled_32sceneCode.GDch3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText4Objects2= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite9Objects1= [];
gdjs.Untitled_32sceneCode.GDNewPanelSprite9Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDNewVideoObjects1= [];
gdjs.Untitled_32sceneCode.GDNewVideoObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewPanelSprite5Objects1Objects = Hashtable.newFrom({"NewPanelSprite5": gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet2Objects1Objects = Hashtable.newFrom({"Bullet2": gdjs.Untitled_32sceneCode.GDBullet2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDRed_95959595ParticleObjects1Objects = Hashtable.newFrom({"Red_Particle": gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiked_95959595BallObjects1Objects = Hashtable.newFrom({"Spiked_Ball": gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSawObjects1Objects = Hashtable.newFrom({"Saw": gdjs.Untitled_32sceneCode.GDSawObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpikesObjects1Objects = Hashtable.newFrom({"Spikes": gdjs.Untitled_32sceneCode.GDSpikesObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWATERObjects1Objects = Hashtable.newFrom({"WATER": gdjs.Untitled_32sceneCode.GDWATERObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet3Objects1Objects = Hashtable.newFrom({"Bullet3": gdjs.Untitled_32sceneCode.GDBullet3Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCheckpointObjects1Objects = Hashtable.newFrom({"Checkpoint": gdjs.Untitled_32sceneCode.GDCheckpointObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AnswerDisplay"), gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("AnswerEntry"), gdjs.Untitled_32sceneCode.GDAnswerEntryObjects1);
gdjs.copyArray(runtimeScene.getObjects("Box2"), gdjs.Untitled_32sceneCode.GDBox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.Untitled_32sceneCode.GDFireObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite3"), gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite4"), gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite7"), gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite8"), gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText3"), gdjs.Untitled_32sceneCode.GDNewText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Untitled_32sceneCode.GDSawObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spiked_Ball"), gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Untitled_32sceneCode.GDSpikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("WATER"), gdjs.Untitled_32sceneCode.GDWATERObjects1);
gdjs.copyArray(runtimeScene.getObjects("_3_EXPLANATION"), gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1);
gdjs.copyArray(runtimeScene.getObjects("_4"), gdjs.Untitled_32sceneCode.GD_95954Objects1);
gdjs.copyArray(runtimeScene.getObjects("ch1"), gdjs.Untitled_32sceneCode.GDch1Objects1);
gdjs.copyArray(runtimeScene.getObjects("ch2"), gdjs.Untitled_32sceneCode.GDch2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ch3"), gdjs.Untitled_32sceneCode.GDch3Objects1);
gdjs.copyArray(runtimeScene.getObjects("food"), gdjs.Untitled_32sceneCode.GDfoodObjects1);
gdjs.copyArray(runtimeScene.getObjects("girlfriend"), gdjs.Untitled_32sceneCode.GDgirlfriendObjects1);
gdjs.copyArray(runtimeScene.getObjects("sacrifice"), gdjs.Untitled_32sceneCode.GDsacrificeObjects1);
gdjs.copyArray(runtimeScene.getObjects("safe"), gdjs.Untitled_32sceneCode.GDsafeObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 3, "", 1);
}
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0] : null), true, "", 1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAnswerEntryObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAnswerEntryObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWATERObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWATERObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSawObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSawObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpikesObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpikesObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBox2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBox2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDsafeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDsafeObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDsacrificeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDsacrificeObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfoodObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfoodObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgirlfriendObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgirlfriendObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GD_95954Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GD_95954Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDch2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDch2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDch1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDch1Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDch3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDch3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText3Objects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite5"), gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewPanelSprite5Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet2"), gdjs.Untitled_32sceneCode.GDBullet2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AnswerDisplay"), gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite3"), gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("AnswerDisplay"), gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite8"), gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText4"), gdjs.Untitled_32sceneCode.GDNewText4Objects1);
gdjs.copyArray(runtimeScene.getObjects("ch1"), gdjs.Untitled_32sceneCode.GDch1Objects1);
gdjs.copyArray(runtimeScene.getObjects("ch2"), gdjs.Untitled_32sceneCode.GDch2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ch3"), gdjs.Untitled_32sceneCode.GDch3Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDch1Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDch1Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDch2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDch2Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDch3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDch3Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText4Objects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText3"), gdjs.Untitled_32sceneCode.GDNewText3Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText3Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Red_Particle"), gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDRed_95959595ParticleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.Untitled_32sceneCode.GDFireObjects1);
gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Untitled_32sceneCode.GDSawObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spiked_Ball"), gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Untitled_32sceneCode.GDSpikesObjects1);
gdjs.copyArray(runtimeScene.getObjects("WATER"), gdjs.Untitled_32sceneCode.GDWATERObjects1);
gdjs.copyArray(runtimeScene.getObjects("_4"), gdjs.Untitled_32sceneCode.GD_95954Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSpikesObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSpikesObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSawObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSawObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWATERObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWATERObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GD_95954Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GD_95954Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.Untitled_32sceneCode.GDSawObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spiked_Ball"), gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spikes"), gdjs.Untitled_32sceneCode.GDSpikesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpiked_95959595BallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSawObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSpikesObjects1Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("WATER"), gdjs.Untitled_32sceneCode.GDWATERObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWATERObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fire"), gdjs.Untitled_32sceneCode.GDFireObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireObjects1[i].getBehavior("Animation").setAnimationName("Off");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet3"), gdjs.Untitled_32sceneCode.GDBullet3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBullet3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Box2"), gdjs.Untitled_32sceneCode.GDBox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("_3_EXPLANATION"), gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBox2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBox2Objects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num5");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num6");
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("safe"), gdjs.Untitled_32sceneCode.GDsafeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDsafeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDsafeObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite4"), gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.Untitled_32sceneCode.GDCheckpointObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCheckpointObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("sacrifice"), gdjs.Untitled_32sceneCode.GDsacrificeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDsacrificeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDsacrificeObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "t");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite5"), gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite6"), gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite7"), gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1);
gdjs.copyArray(runtimeScene.getObjects("Trophy"), gdjs.Untitled_32sceneCode.GDTrophyObjects1);
gdjs.copyArray(runtimeScene.getObjects("girlfriend"), gdjs.Untitled_32sceneCode.GDgirlfriendObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDgirlfriendObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDgirlfriendObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTrophyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTrophyObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPanelSprite6"), gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1);
gdjs.copyArray(runtimeScene.getObjects("food"), gdjs.Untitled_32sceneCode.GDfoodObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDfoodObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDfoodObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDColored_9595ConfettiObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDColored_9595ConfettiObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLeaves_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLeaves_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDust_9595ParticleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDust_9595ParticleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595Grass_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595Grass_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595Grass_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595Grass_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595Grass_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595Grass_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWood_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWood_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStone_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStone_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStone_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStone_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595PiecesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595PiecesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWood_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWood_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDLeafsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLeafsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595ParticleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595ParticleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAppearingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAppearingObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDGost_9595ParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGost_9595ParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSlime_9595ParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSlime_9595ParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChainObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDChainObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpikesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpikesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDesappearingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDesappearingObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFalling_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFalling_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFanObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFanObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChain2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDChain2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDFireObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFireObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRock_9595HeadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRock_9595HeadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSawObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSawObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTrampolineObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTrampolineObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpike_9595HeadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpike_9595HeadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChain3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDChain3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpoint_95952Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpoint_95952Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpointObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpointObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTrophyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTrophyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBox1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBox1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBox3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBox3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBox2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBox2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAppleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAppleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBananasObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBananasObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDKiwiObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDKiwiObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMelonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMelonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCherriesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCherriesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCollectedObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCollectedObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPineappleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPineappleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStrawberryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStrawberryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAngryPigObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAngryPigObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBatObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBatObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBirdObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBirdObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerEntryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerEntryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDWATERObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWATERObjects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95953Objects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95953Objects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95952Objects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95952Objects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDsafeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDsafeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDsacrificeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDsacrificeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDfoodObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfoodObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgirlfriendObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgirlfriendObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95954Objects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95954Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDch1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDch1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDch2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDch2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDch3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDch3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewVideoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewVideoObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTransitionObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDColored_9595ConfettiObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDColored_9595ConfettiObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDShadowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLeaves_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLeaves_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDust_9595ParticleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDust_9595ParticleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595Grass_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreen_9595Grass_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595Grass_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595Grass_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595Grass_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPink_9595Grass_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWood_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWood_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStone_95959PatchObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStone_95959PatchObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStone_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStone_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595PiecesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595PiecesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWood_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWood_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDLeafsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLeafsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595ParticleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrange_9595ParticleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRed_9595ParticleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAppearingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAppearingObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet_9595Pieces3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBullet3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBullet3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDGost_9595ParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGost_9595ParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSlime_9595ParticlesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSlime_9595ParticlesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChainObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDChainObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpiked_9595BallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpikesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpikesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDesappearingObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDesappearingObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDArrowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFalling_9595PlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFalling_9595PlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFanObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFanObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChain2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDChain2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDFireObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFireObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlatformObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRock_9595HeadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRock_9595HeadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSawObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSawObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTrampolineObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTrampolineObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSpike_9595HeadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSpike_9595HeadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChain3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDChain3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpoint_95952Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpoint_95952Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpointObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCheckpointObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTrophyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTrophyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBox1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBox1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBox3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBox3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBox2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBox2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDAppleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAppleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBananasObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBananasObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDKiwiObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDKiwiObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMelonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMelonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCherriesObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCherriesObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCollectedObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCollectedObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDOrangeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPineappleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPineappleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStrawberryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStrawberryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAngryPigObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAngryPigObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBatObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBatObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBirdObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBirdObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerEntryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerEntryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDAnswerDisplayObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDWATERObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWATERObjects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95953Objects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95953Objects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95952Objects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95952Objects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95953_9595EXPLANATIONObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDsafeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDsafeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDsacrificeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDsacrificeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDfoodObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDfoodObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgirlfriendObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgirlfriendObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GD_95954Objects1.length = 0;
gdjs.Untitled_32sceneCode.GD_95954Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDch1Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDch1Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDch2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDch2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDch3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDch3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewPanelSprite9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewVideoObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewVideoObjects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
